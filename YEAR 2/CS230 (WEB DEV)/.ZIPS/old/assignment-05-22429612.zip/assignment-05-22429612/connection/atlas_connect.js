module.exports = {
    database: {
        url: "mongodb+srv://dbUser:dbUser-240@clusterdb.divzee2.mongodb.net/?retryWrites=true&w=majority&appName=ClusterDB"
    }
}